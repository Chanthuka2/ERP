/**
 * Web Studio ERP — Shantera Web Solutions + Kloud Code
 * Google Sheets + Apps Script
 *
 * First time: run setup() once from the editor.
 * Optional : run importExisting() to add the two invoices already issued (Lily Fragrance, Event by Windy).
 * Default login: admin / admin123  (change it after the first login)
 *
 * The offline app (GitHub Pages) talks to this script through doPost.
 * Deploy as Web app: Execute as Me · Who has access: Anyone.
 */

var LITE = false;   // true while a sync batch runs: write functions skip the full data reload

/* ───────── JSON API for the offline app ───────── */
var API = {
  ping: function () { return { ok: true, time: new Date().toISOString() }; },
  login: login, logout: logout, bootstrap: bootstrap, refresh: refresh, sync: sync,
  saveCompany: saveCompany, changePassword: changePassword, addUser: addUser
};
function doPost(e) {
  var out;
  try {
    var req = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    var fn = API[req.fn];
    if (!fn) throw new Error('Unknown action: ' + req.fn);
    out = { ok: true, result: fn.apply(null, req.args || []) };
  } catch (err) {
    out = { ok: false, error: String((err && err.message) || err) };
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

/** Runs queued offline changes in order. Safe to send twice: each change has a reqId that is only applied once. */
function sync(token, ops) {
  var s = auth_(token);
  return withLock_(function () {
    var done = {};
    rows_('Sync').forEach(function (r) { try { done[r.ReqID] = JSON.parse(r.Result || '{}'); } catch (e) { done[r.ReqID] = {}; } });
    var idmap = {}, results = [];
    LITE = true;
    try {
      (ops || []).forEach(function (op) {
        if (done[op.reqId]) {
          var d0 = done[op.reqId];
          if (d0.tmp && d0.id) idmap[d0.tmp] = d0.id;
          results.push({ reqId: op.reqId, ok: true, id: d0.id || '', repeat: true });
          return;
        }
        var p = mapIds_(op.payload || {}, idmap);
        try {
          var h = OPS[op.type];
          if (!h) throw new Error('Unknown change type ' + op.type);
          var id = h(token, p, s);
          if (p.tmp && id) idmap[p.tmp] = String(id);
          var rec = { tmp: p.tmp || '', id: id ? String(id) : '' };
          append_('Sync', { ReqID: op.reqId, Type: op.type, Result: JSON.stringify(rec), User: s.u, Date: new Date() });
          done[op.reqId] = rec;
          results.push({ reqId: op.reqId, ok: true, id: rec.id });
        } catch (err) {
          results.push({ reqId: op.reqId, ok: false, error: String(err.message || err), type: op.type });
        }
      });
    } finally { LITE = false; }
    return { results: results, idmap: idmap, data: allData_() };
  });
}
function notTemp_(v, what) { if (/^(DRAFT|NEW)-/.test(String(v || ''))) throw new Error(what + ' was created offline but could not be saved earlier'); }
var OPS = {
  saveDoc: function (t, p) { notTemp_(p.docNo, 'This document'); notTemp_(p.clientId, 'The client'); return saveDoc(t, p).no; },
  addPayment: function (t, p) { notTemp_(p.docNo, 'The invoice'); return addPayment(t, p).receipt; },
  saveClient: function (t, p) { notTemp_(p.id, 'The client'); return saveClient(t, p).client.id; },
  setDocStatus: function (t, p) { notTemp_(p.no, 'The document'); setDocStatus(t, p.no, p.status); return p.no; },
  deleteDoc: function (t, p) { notTemp_(p.no, 'The document'); deleteDoc(t, p.no); return p.no; },
  saveProject: function (t, p) { notTemp_(p.id, 'The project'); notTemp_(p.clientId, 'The client'); return saveProject(t, p); },
  saveRenewal: function (t, p) { notTemp_(p.id, 'The renewal'); notTemp_(p.clientId, 'The client'); return saveRenewal(t, p); },
  saveExpense: function (t, p) { notTemp_(p.id, 'The expense'); return saveExpense(t, p); },
  deleteExpense: function (t, p) { notTemp_(p.id, 'The expense'); deleteExpense(t, p.id); return p.id; }
};
function mapIds_(payload, idmap) {
  var s = JSON.stringify(payload);
  Object.keys(idmap).forEach(function (k) { s = s.split(k).join(idmap[k]); });
  return JSON.parse(s);
}
function data_() { return LITE ? null : allData_(); }

var SHEETS = {
  Users:     ['Username', 'PasswordHash', 'Salt', 'Name', 'Role', 'Active', 'Created'],
  Companies: ['Code', 'Name', 'Tagline', 'Website', 'Phone', 'Email', 'Address', 'AccountName', 'AccountNo', 'Bank', 'Branch',
              'Prefix', 'HeaderColor', 'AccentColor', 'LightColor', 'HighlightColor'],
  Clients:   ['ID', 'Name', 'Business', 'Phone', 'Email', 'Address', 'NIC', 'Notes', 'Created'],
  Docs:      ['DocNo', 'Type', 'Company', 'Date', 'ClientID', 'ClientName', 'Project', 'Website', 'Currency', 'Total', 'Paid', 'Balance',
              'DueMode', 'DueDate', 'Status', 'Terms', 'Notes', 'FromDoc', 'User', 'Created'],
  DocItems:  ['DocNo', 'Line', 'Description', 'Detail', 'Amount', 'Free'],
  DocCosts:  ['DocNo', 'Line', 'Label', 'Amount'],
  Payments:  ['ReceiptNo', 'Date', 'DocNo', 'Company', 'ClientName', 'Currency', 'Amount', 'Method', 'Label', 'Note', 'User'],
  Projects:  ['ID', 'Company', 'ClientID', 'ClientName', 'Name', 'Website', 'Value', 'Currency', 'Status', 'Start', 'Deadline', 'Notes', 'Updated'],
  Renewals:  ['ID', 'Company', 'ClientID', 'ClientName', 'Service', 'Item', 'Amount', 'Currency', 'Cycle', 'NextDate', 'Status', 'Notes'],
  Expenses:  ['ID', 'Date', 'Company', 'Category', 'Description', 'Amount', 'Currency', 'Method', 'User'],
  Services:  ['Company', 'Name', 'Detail', 'Price', 'Currency'],
  Sessions:  ['Token', 'Username', 'Name', 'Role', 'Expires'],
  Sync:      ['ReqID', 'Type', 'Result', 'User', 'Date'],
  Settings:  ['Key', 'Value']
};

var TEXT_COLS = {
  Users: ['Username'], Companies: ['Code', 'Phone', 'AccountNo', 'Prefix'], Clients: ['ID', 'Phone', 'NIC'],
  Docs: ['DocNo', 'ClientID', 'FromDoc', 'Terms'], DocItems: ['DocNo'], DocCosts: ['DocNo'], Payments: ['ReceiptNo', 'DocNo'],
  Projects: ['ID', 'ClientID'], Renewals: ['ID', 'ClientID'], Expenses: ['ID'], Settings: ['Key', 'Value'],
  Sessions: ['Token', 'Username'], Sync: ['ReqID', 'Result']
};

var DEFAULT_COMPANIES = [
  { Code: 'SWS', Name: 'Shantera Web Solutions', Tagline: 'Simplify Your Business', Website: 'shantera.lk', Phone: '', Email: '', Address: '',
    AccountName: 'R L Wickramaarachchi', AccountNo: '005950009472', Bank: 'Sampath Bank', Branch: 'Bandaragama',
    Prefix: 'SWS', HeaderColor: '#0B1A33', AccentColor: '#1565E0', LightColor: '#EAF2FD', HighlightColor: '#7FB6FF' },
  { Code: 'KC', Name: 'Kloud Code', Tagline: 'Web Development Company', Website: 'kloud.lk', Phone: '078 314 1130', Email: '', Address: '',
    AccountName: '', AccountNo: '', Bank: '', Branch: '',
    Prefix: 'KC', HeaderColor: '#0A0A0A', AccentColor: '#4FA80B', LightColor: '#F1FBE6', HighlightColor: '#83FB0D' }
];

var DEFAULT_SERVICES = [
  ['ALL', 'Website Package', 'Web Development | On-page SEO | Hosting & Domain (1st year)', 80000, 'LKR'],
  ['ALL', 'Website Development', '', 50000, 'LKR'],
  ['ALL', 'Domain Registration (.lk, 1 year)', '', 4500, 'LKR'],
  ['ALL', 'Domain Registration (.com, 1 year)', '', 4500, 'LKR'],
  ['ALL', 'Web Hosting - 1st year', '', 0, 'LKR'],
  ['ALL', 'Web Hosting Renewal (1 year)', '', 12000, 'LKR'],
  ['ALL', 'Website Maintenance (monthly)', 'Updates, backups and small changes', 5000, 'LKR'],
  ['ALL', 'On-page SEO', '', 15000, 'LKR'],
  ['ALL', 'Website Development', '', 300, 'USD']
];

/* ───────── web app ───────── */
function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Studio ERP · Shantera & Kloud Code')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, viewport-fit=cover')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/* ───────── setup ───────── */
function setup() {
  var ss = ss_();
  Object.keys(SHEETS).forEach(function (name) {
    var sh = ss.getSheetByName(name) || ss.insertSheet(name);
    var head = SHEETS[name];
    sh.getRange(1, 1, 1, head.length).setValues([head]).setFontWeight('bold').setBackground('#0B1A33').setFontColor('#FFFFFF');
    sh.setFrozenRows(1);
    (TEXT_COLS[name] || []).forEach(function (col) {
      sh.getRange(2, head.indexOf(col) + 1, sh.getMaxRows() - 1, 1).setNumberFormat('@');
    });
  });
  var blank = ss.getSheetByName('Sheet1');
  if (blank && blank.getLastRow() === 0) ss.deleteSheet(blank);
  if (!rows_('Companies').length) DEFAULT_COMPANIES.forEach(function (c) { append_('Companies', c); });
  if (!rows_('Services').length) DEFAULT_SERVICES.forEach(function (s) {
    append_('Services', { Company: s[0], Name: s[1], Detail: s[2], Price: s[3], Currency: s[4] });
  });
  var st = settings_();
  ['ClientCounter', 'ProjectCounter', 'RenewalCounter', 'ExpenseCounter', 'ReceiptCounter'].forEach(function (k) {
    if (st[k] === undefined) append_('Settings', { Key: k, Value: '0' });
  });
  if (st.ExpenseCategories === undefined) append_('Settings', { Key: 'ExpenseCategories', Value: 'Hosting,Domains,Freelancers,Software,Advertising,Internet & Phone,Transport,Other' });
  if (!rows_('Users').length) {
    var salt = Utilities.getUuid();
    append_('Users', { Username: 'admin', PasswordHash: hash_('admin123', salt), Salt: salt, Name: 'Admin', Role: 'Admin', Active: true, Created: new Date() });
  }
  return 'Setup complete. Login with admin / admin123';
}

/** Adds the two invoices already issued from Shantera (from the PDFs). Run once. */
function importExisting() {
  if (rows_('Docs').some(function (d) { return d.DocNo === 'SWS-2026-1117'; })) return 'Already imported';
  var c1 = addClient_({ name: 'Dilshan Sandaruwan', business: 'Lily Fragrance', phone: '077 240 2450', email: 'sampath.uditha@gmail.com',
    address: '25/19, Gramasanwardana Road, Boralesgamuwa' });
  var c2 = addClient_({ name: 'Vindya Hansani Wijesinghe', business: 'Event by Windy', phone: '076 021 8088', email: 'vindyahansani6@gmail.com',
    address: 'No 25, Graceland Outer Circular Road, Horana', nic: '200277201961' });
  var d = new Date(2026, 10, 17);
  writeDoc_({ docNo: 'SWS-2026-1117', type: 'Invoice', company: 'SWS', date: d, clientId: c1.id, project: 'Lily Fragrance', website: 'www.lilyfragrance.lk',
    currency: 'LKR', dueMode: 'date', dueDate: '2026-12-15',
    items: [{ description: 'Website Development - Lily Fragrance (www.lilyfragrance.lk)', amount: 50000 },
            { description: 'Domain Registration - lilyfragrance.lk (1 year)', amount: 4500 },
            { description: 'Web Hosting - 1st year', amount: 0, free: true }],
    terms: '1st installment of LKR 29,500.00 received with thanks.\nThe balance (2nd installment) of LKR 25,000.00 is to be paid on or before 15 December 2026.\nHosting is free for the first year; renewal charges apply from the second year onwards.' }, 'admin');
  addPayment_({ docNo: 'SWS-2026-1117', amount: 29500, label: '1st Installment Paid', method: 'Bank transfer', date: d }, 'admin');
  writeDoc_({ docNo: 'SWS-2026-1117-02', type: 'Invoice', company: 'SWS', date: d, clientId: c2.id, project: 'Event by Windy', website: 'www.eventbywindyev.com',
    currency: 'LKR', dueMode: 'receipt',
    items: [{ description: 'Website Package - Event by Windy (www.eventbywindyev.com)', detail: 'Web Development | On-page SEO | Hosting & Domain (1st year)', amount: 80000 }],
    terms: 'Advance payment of LKR 30,000.00 received with thanks.\nThe website has been completed and handed over to the client.\nThe balance of LKR 50,000.00 is now due. Kindly settle it upon receipt of this invoice.\nHosting & domain are included for the first year; renewal charges apply from the second year onwards.' }, 'admin');
  addPayment_({ docNo: 'SWS-2026-1117-02', amount: 30000, label: 'Advance Paid', method: 'Bank transfer', date: d }, 'admin');
  [[c1, 'Lily Fragrance', 'www.lilyfragrance.lk', 50000, 'Development'], [c2, 'Event by Windy', 'www.eventbywindyev.com', 80000, 'Live']].forEach(function (p) {
    append_('Projects', { ID: nextNo_('ProjectCounter', 'P', 4), Company: 'SWS', ClientID: p[0].id, ClientName: p[0].name, Name: p[1], Website: p[2],
      Value: p[3], Currency: 'LKR', Status: p[4], Start: d, Deadline: '', Notes: '', Updated: new Date() });
  });
  [[c1, 'Domain', 'lilyfragrance.lk', 4500], [c1, 'Hosting', 'lilyfragrance.lk hosting', 12000], [c2, 'Hosting & Domain', 'eventbywindyev.com', 16500]].forEach(function (r) {
    append_('Renewals', { ID: nextNo_('RenewalCounter', 'R', 4), Company: 'SWS', ClientID: r[0].id, ClientName: r[0].name, Service: r[1], Item: r[2],
      Amount: r[3], Currency: 'LKR', Cycle: 'Yearly', NextDate: new Date(2027, 10, 17), Status: 'Active', Notes: '' });
  });
  return 'Imported 2 invoices, 2 clients, 2 projects, 3 renewals';
}

/* ───────── auth ───────── */
function login(username, password) {
  var u = String(username || '').trim().toLowerCase();
  var user = rows_('Users').filter(function (r) { return String(r.Username).toLowerCase() === u && isOn_(r.Active); })[0];
  if (!user || hash_(String(password || ''), user.Salt) !== user.PasswordHash) throw new Error('Wrong user name or password');
  var token = Utilities.getUuid() + Utilities.getUuid().slice(0, 8), sess = { u: user.Username, n: user.Name, r: user.Role };
  CacheService.getScriptCache().put('s_' + token, JSON.stringify(sess), 21600);
  append_('Sessions', { Token: token, Username: user.Username, Name: user.Name, Role: user.Role, Expires: new Date(Date.now() + 90 * 864e5) });
  return { token: token };
}
function logout(token) {
  CacheService.getScriptCache().remove('s_' + token);
  var r = rows_('Sessions').filter(function (x) { return x.Token === token; })[0];
  if (r) setCells_('Sessions', r._row, { Expires: new Date(0) });
  return true;
}
function changePassword(token, oldPw, newPw) {
  var s = auth_(token);
  if (String(newPw || '').length < 6) throw new Error('New password must be at least 6 characters');
  var user = rows_('Users').filter(function (r) { return r.Username === s.u; })[0];
  if (!user || hash_(oldPw, user.Salt) !== user.PasswordHash) throw new Error('Current password is wrong');
  var salt = Utilities.getUuid();
  setCells_('Users', user._row, { PasswordHash: hash_(newPw, salt), Salt: salt });
  return true;
}
function addUser(token, u) {
  var s = auth_(token);
  if (s.r !== 'Admin') throw new Error('Only an admin can add users');
  var name = String(u.username || '').trim();
  if (!name || String(u.password || '').length < 6) throw new Error('User name and a 6+ character password are needed');
  if (rows_('Users').some(function (r) { return String(r.Username).toLowerCase() === name.toLowerCase(); })) throw new Error('That user name already exists');
  var salt = Utilities.getUuid();
  append_('Users', { Username: name, PasswordHash: hash_(u.password, salt), Salt: salt, Name: u.name || name, Role: u.role === 'Admin' ? 'Admin' : 'Staff', Active: true, Created: new Date() });
  return true;
}

/* ───────── data load ───────── */
function bootstrap(token) {
  var s = auth_(token);
  var st = settings_();
  return {
    user: { username: s.u, name: s.n, role: s.r },
    companies: companies_(),
    expenseCategories: String(st.ExpenseCategories || '').split(',').map(function (x) { return x.trim(); }).filter(String),
    data: allData_()
  };
}
function allData_() {
  var items = {};
  rows_('DocItems').forEach(function (r) {
    (items[r.DocNo] = items[r.DocNo] || []).push({ line: num_(r.Line), description: r.Description, detail: r.Detail, amount: num_(r.Amount), free: isOn_(r.Free) });
  });
  var costs = {};
  rows_('DocCosts').forEach(function (r) {
    (costs[r.DocNo] = costs[r.DocNo] || []).push({ line: num_(r.Line), label: r.Label, amount: num_(r.Amount) });
  });
  var pays = {};
  var payments = rows_('Payments').map(function (p) {
    var o = { no: p.ReceiptNo, date: ymd_(p.Date), docNo: p.DocNo, company: p.Company, client: p.ClientName, currency: p.Currency,
      amount: num_(p.Amount), method: p.Method, label: p.Label, note: p.Note, user: p.User };
    (pays[p.DocNo] = pays[p.DocNo] || []).push(o);
    return o;
  });
  return {
    clients: rows_('Clients').map(function (c) {
      return { id: String(c.ID), name: c.Name, business: c.Business, phone: String(c.Phone), email: c.Email, address: c.Address, nic: String(c.NIC), notes: c.Notes };
    }),
    docs: rows_('Docs').map(function (d) {
      return { no: d.DocNo, type: d.Type, company: d.Company, date: ymd_(d.Date), clientId: String(d.ClientID), client: d.ClientName, project: d.Project,
        website: d.Website, currency: d.Currency || 'LKR', total: num_(d.Total), paid: num_(d.Paid), balance: num_(d.Balance), dueMode: d.DueMode || 'date',
        dueDate: d.DueDate ? ymd_(d.DueDate) : '', status: d.Status, terms: String(d.Terms || ''), notes: d.Notes, fromDoc: String(d.FromDoc || ''),
        items: (items[d.DocNo] || []).sort(function (a, b) { return a.line - b.line; }), payments: pays[d.DocNo] || [],
        costs: (costs[d.DocNo] || []).sort(function (a, b) { return a.line - b.line; }) };
    }),
    payments: payments,
    projects: rows_('Projects').map(function (p) {
      return { id: String(p.ID), company: p.Company, clientId: String(p.ClientID), client: p.ClientName, name: p.Name, website: p.Website,
        value: num_(p.Value), currency: p.Currency || 'LKR', status: p.Status, start: p.Start ? ymd_(p.Start) : '', deadline: p.Deadline ? ymd_(p.Deadline) : '', notes: p.Notes };
    }),
    renewals: rows_('Renewals').map(function (r) {
      return { id: String(r.ID), company: r.Company, clientId: String(r.ClientID), client: r.ClientName, service: r.Service, item: r.Item,
        amount: num_(r.Amount), currency: r.Currency || 'LKR', cycle: r.Cycle, next: r.NextDate ? ymd_(r.NextDate) : '', status: r.Status, notes: r.Notes };
    }),
    expenses: rows_('Expenses').map(function (e) {
      return { id: String(e.ID), date: ymd_(e.Date), company: e.Company, category: e.Category, description: e.Description, amount: num_(e.Amount),
        currency: e.Currency || 'LKR', method: e.Method, user: e.User };
    }),
    services: rows_('Services').map(function (s) { return { company: s.Company, name: s.Name, detail: s.Detail, price: num_(s.Price), currency: s.Currency || 'LKR' }; }),
    today: ymd_(new Date())
  };
}
function refresh(token) { auth_(token); return allData_(); }
function companies_() {
  return rows_('Companies').map(function (c) {
    var o = {}; SHEETS.Companies.forEach(function (k) { o[k] = String(c[k] === undefined ? '' : c[k]); }); return o;
  });
}

/* ───────── companies ───────── */
function saveCompany(token, c) {
  var s = auth_(token);
  if (s.r !== 'Admin') throw new Error('Only an admin can change company details');
  return withLock_(function () {
    var row = rows_('Companies').filter(function (r) { return r.Code === c.Code; })[0];
    if (!row) throw new Error('Company not found');
    var upd = {};
    ['Name', 'Tagline', 'Website', 'Phone', 'Email', 'Address', 'AccountName', 'AccountNo', 'Bank', 'Branch'].forEach(function (k) { if (c[k] !== undefined) upd[k] = String(c[k]).trim(); });
    setCells_('Companies', row._row, upd);
    return companies_();
  });
}

/* ───────── clients ───────── */
function saveClient(token, c) {
  auth_(token);
  return withLock_(function () {
    if (!String(c.name || '').trim()) throw new Error('Client name is required');
    if (c.id) {
      var row = rows_('Clients').filter(function (r) { return String(r.ID) === String(c.id); })[0];
      if (!row) throw new Error('Client not found');
      setCells_('Clients', row._row, { Name: c.name.trim(), Business: c.business || '', Phone: c.phone || '', Email: c.email || '', Address: c.address || '', NIC: c.nic || '', Notes: c.notes || '' });
      return { client: { id: String(c.id) }, data: data_() };
    }
    var done = seen_(c.reqId);
    if (done) return { client: { id: done }, data: data_() };
    var nc = addClient_(c);
    remember_(c.reqId, nc.id);
    return { client: nc, data: data_() };
  });
}
function addClient_(c) {
  var id = nextNo_('ClientCounter', 'CL', 4);
  append_('Clients', { ID: id, Name: String(c.name).trim(), Business: c.business || '', Phone: c.phone || '', Email: c.email || '', Address: c.address || '',
    NIC: c.nic || '', Notes: c.notes || '', Created: new Date() });
  return { id: id, name: String(c.name).trim() };
}

/* ───────── invoices & quotations ───────── */
function seen_(reqId) { return reqId ? CacheService.getScriptCache().get('req_' + reqId) : null; }
function remember_(reqId, val) { if (reqId) CacheService.getScriptCache().put('req_' + reqId, String(val), 21600); }

function saveDoc(token, d) {
  var s = auth_(token);
  return withLock_(function () {
    var done = seen_(d.reqId);
    if (done) return { no: done, data: data_(), repeat: true };
    var no = writeDoc_(d, s.u);
    remember_(d.reqId, no);
    if (d.payment && num_(d.payment.amount) > 0) addPayment_({ docNo: no, amount: d.payment.amount, label: d.payment.label, method: d.payment.method, date: d.payment.date }, s.u);
    if (d.renewalId) bumpRenewal_(d.renewalId);
    if (d.fromDoc) {
      var q = rows_('Docs').filter(function (r) { return r.DocNo === d.fromDoc; })[0];
      if (q && q.Type === 'Quotation') setCells_('Docs', q._row, { Status: 'Accepted' });
    }
    return { no: no, data: data_() };
  });
}

function writeDoc_(d, user) {
  var comp = companies_().filter(function (c) { return c.Code === d.company; })[0];
  if (!comp) throw new Error('Choose a company');
  var client = rows_('Clients').filter(function (r) { return String(r.ID) === String(d.clientId); })[0];
  if (!client) throw new Error('Choose a client');
  var items = (d.items || []).filter(function (i) { return String(i.description || '').trim(); });
  if (!items.length) throw new Error('Add at least one line item');
  var total = round_(items.reduce(function (t, i) { return t + (i.free ? 0 : num_(i.amount)); }, 0));
  var type = d.type === 'Quotation' ? 'Quotation' : 'Invoice';
  var date = d.date instanceof Date ? d.date : (d.date ? new Date(d.date + 'T00:00:00') : new Date());
  var docs = rows_('Docs');
  var existing = d.docNo ? docs.filter(function (r) { return r.DocNo === d.docNo; })[0] : null;
  if (d.docNo && !existing && /^DRAFT-/.test(d.docNo)) throw new Error('Draft ' + d.docNo + ' was not saved');
  var no = existing ? existing.DocNo : (d.docNo || nextDocNo_(comp.Prefix, type, date, docs));
  var paid = existing ? num_(existing.Paid) : 0;
  if (existing && existing.Status === 'Cancelled') throw new Error('A cancelled document cannot be edited');
  if (total < paid) throw new Error('Total cannot be less than the amount already paid (' + paid + ')');
  var rec = { DocNo: no, Type: type, Company: comp.Code, Date: date, ClientID: String(client.ID), ClientName: client.Name, Project: d.project || '',
    Website: d.website || '', Currency: d.currency === 'USD' ? 'USD' : 'LKR', Total: total, Paid: paid, Balance: round_(total - paid),
    DueMode: d.dueMode === 'receipt' ? 'receipt' : 'date', DueDate: d.dueMode === 'receipt' || !d.dueDate ? '' : new Date(d.dueDate + 'T00:00:00'),
    Status: statusOf_(type, total, paid, existing ? existing.Status : ''), Terms: String(d.terms || ''), Notes: d.notes || '', FromDoc: d.fromDoc || '',
    User: user, Created: existing ? existing.Created : new Date() };
  if (existing) {
    setCells_('Docs', existing._row, rec);
    ['DocItems', 'DocCosts'].forEach(function (name) {
      var sh = sh_(name);
      rows_(name).filter(function (r) { return r.DocNo === no; }).map(function (r) { return r._row; })
        .sort(function (a, b) { return b - a; }).forEach(function (r) { sh.deleteRow(r); });
    });
  } else {
    append_('Docs', rec);
  }
  appendMany_('DocItems', items.map(function (i, k) {
    return { DocNo: no, Line: k + 1, Description: String(i.description).trim(), Detail: i.detail || '', Amount: i.free ? 0 : num_(i.amount), Free: !!i.free };
  }));
  appendMany_('DocCosts', (d.costs || []).filter(function (c) { return num_(c.amount) > 0; }).map(function (c, k) {
    return { DocNo: no, Line: k + 1, Label: String(c.label || 'Cost').trim() || 'Cost', Amount: num_(c.amount) };
  }));
  return no;
}

function statusOf_(type, total, paid, prev) {
  if (type === 'Quotation') return prev && prev !== 'Draft' ? prev : 'Sent';
  if (prev === 'Cancelled') return 'Cancelled';
  if (paid >= total - 0.009 && total > 0) return 'Paid';
  if (paid > 0) return 'Part paid';
  return 'Unpaid';
}

function nextDocNo_(prefix, type, date, docs) {
  var base = prefix + (type === 'Quotation' ? '-Q-' : '-') + Utilities.formatDate(date, Session.getScriptTimeZone(), 'yyyy-MMdd');
  var used = {};
  docs.forEach(function (r) { used[r.DocNo] = 1; });
  if (!used[base]) return base;
  for (var n = 2; n < 100; n++) { var c = base + '-' + ('0' + n).slice(-2); if (!used[c]) return c; }
  throw new Error('Too many documents today');
}

function addPayment(token, p) {
  var s = auth_(token);
  return withLock_(function () {
    var done = seen_(p.reqId);
    if (done) return { receipt: done, data: data_(), repeat: true };
    var r = addPayment_(p, s.u);
    remember_(p.reqId, r);
    return { receipt: r, data: data_() };
  });
}
function addPayment_(p, user) {
  var doc = rows_('Docs').filter(function (r) { return r.DocNo === p.docNo; })[0];
  if (!doc) throw new Error('Invoice not found');
  if (doc.Type !== 'Invoice') throw new Error('Payments can only be added to invoices');
  if (doc.Status === 'Cancelled') throw new Error('This invoice is cancelled');
  var amt = round_(num_(p.amount)), bal = num_(doc.Balance);
  if (amt <= 0) throw new Error('Enter the amount received');
  if (amt > bal + 0.009) throw new Error('Amount is more than the balance (' + bal.toFixed(2) + ')');
  var count = rows_('Payments').filter(function (r) { return r.DocNo === doc.DocNo; }).length;
  var label = String(p.label || '').trim() || (ordinal_(count + 1) + ' Installment Paid');
  var no = nextNo_('ReceiptCounter', 'RC-', 5);
  var date = p.date instanceof Date ? p.date : (p.date ? new Date(p.date + 'T00:00:00') : new Date());
  append_('Payments', { ReceiptNo: no, Date: date, DocNo: doc.DocNo, Company: doc.Company, ClientName: doc.ClientName, Currency: doc.Currency || 'LKR',
    Amount: amt, Method: p.method || 'Bank transfer', Label: label, Note: p.note || '', User: user });
  var paid = round_(num_(doc.Paid) + amt), total = num_(doc.Total);
  setCells_('Docs', doc._row, { Paid: paid, Balance: round_(total - paid), Status: statusOf_('Invoice', total, paid, doc.Status) });
  return no;
}

function setDocStatus(token, no, status) {
  auth_(token);
  return withLock_(function () {
    var doc = rows_('Docs').filter(function (r) { return r.DocNo === no; })[0];
    if (!doc) throw new Error('Document not found');
    var allowed = doc.Type === 'Quotation' ? ['Sent', 'Accepted', 'Rejected', 'Cancelled'] : ['Cancelled', 'Reopen'];
    if (allowed.indexOf(status) < 0) throw new Error('Not allowed');
    if (status === 'Cancelled' && num_(doc.Paid) > 0) throw new Error('This invoice has payments. It cannot be cancelled.');
    var st = status === 'Reopen' ? statusOf_('Invoice', num_(doc.Total), num_(doc.Paid), '') : status;
    setCells_('Docs', doc._row, { Status: st });
    return data_();
  });
}

/** Admin only: removes a document with its lines and payments for good. */
function deleteDoc(token, no) {
  var s = auth_(token);
  if (s.r !== 'Admin') throw new Error('Only an admin can delete documents');
  return withLock_(function () {
    var doc = rows_('Docs').filter(function (r) { return r.DocNo === no; })[0];
    if (!doc) throw new Error('Document not found');
    ['Payments', 'DocItems', 'DocCosts'].forEach(function (name) {
      var sh = sh_(name);
      rows_(name).filter(function (r) { return r.DocNo === no; }).map(function (r) { return r._row; })
        .sort(function (a, b) { return b - a; }).forEach(function (r) { sh.deleteRow(r); });
    });
    rows_('Docs').filter(function (r) { return r.FromDoc === no; }).forEach(function (r) { setCells_('Docs', r._row, { FromDoc: '' }); });
    sh_('Docs').deleteRow(doc._row);
    return data_();
  });
}

function ordinal_(n) { var s = ['th', 'st', 'nd', 'rd'], v = n % 100; return n + (s[(v - 20) % 10] || s[v] || s[0]); }

/* ───────── projects / renewals / expenses ───────── */
function saveProject(token, p) {
  auth_(token);
  return withLock_(function () {
    if (!String(p.name || '').trim()) throw new Error('Project name is required');
    var cl = rows_('Clients').filter(function (r) { return String(r.ID) === String(p.clientId); })[0];
    var rec = { Company: p.company, ClientID: cl ? String(cl.ID) : '', ClientName: cl ? cl.Name : '', Name: p.name.trim(), Website: p.website || '',
      Value: num_(p.value), Currency: p.currency === 'USD' ? 'USD' : 'LKR', Status: p.status || 'Lead', Start: p.start ? new Date(p.start + 'T00:00:00') : '',
      Deadline: p.deadline ? new Date(p.deadline + 'T00:00:00') : '', Notes: p.notes || '', Updated: new Date() };
    if (p.id) {
      var row = rows_('Projects').filter(function (r) { return String(r.ID) === String(p.id); })[0];
      if (!row) throw new Error('Project not found');
      setCells_('Projects', row._row, rec);
    } else { rec.ID = nextNo_('ProjectCounter', 'P', 4); append_('Projects', rec); }
    return LITE ? (p.id || rec.ID) : allData_();
  });
}
function saveRenewal(token, r) {
  auth_(token);
  return withLock_(function () {
    if (!String(r.item || '').trim()) throw new Error('Enter what is being renewed (e.g. domain name)');
    if (!r.next) throw new Error('Enter the renewal date');
    var cl = rows_('Clients').filter(function (x) { return String(x.ID) === String(r.clientId); })[0];
    if (!cl) throw new Error('Choose a client');
    var rec = { Company: r.company, ClientID: String(cl.ID), ClientName: cl.Name, Service: r.service || 'Hosting', Item: r.item.trim(), Amount: num_(r.amount),
      Currency: r.currency === 'USD' ? 'USD' : 'LKR', Cycle: r.cycle === 'Monthly' ? 'Monthly' : 'Yearly', NextDate: new Date(r.next + 'T00:00:00'),
      Status: r.status === 'Cancelled' ? 'Cancelled' : 'Active', Notes: r.notes || '' };
    if (r.id) {
      var row = rows_('Renewals').filter(function (x) { return String(x.ID) === String(r.id); })[0];
      if (!row) throw new Error('Renewal not found');
      setCells_('Renewals', row._row, rec);
    } else { rec.ID = nextNo_('RenewalCounter', 'R', 4); append_('Renewals', rec); }
    return LITE ? (r.id || rec.ID) : allData_();
  });
}
function bumpRenewal_(id) {
  var r = rows_('Renewals').filter(function (x) { return String(x.ID) === String(id); })[0];
  if (!r) return;
  var d = asDate_(r.NextDate), n = r.Cycle === 'Monthly' ? 1 : 12;
  var x = new Date(d.getFullYear(), d.getMonth() + n, 1);
  x.setDate(Math.min(d.getDate(), new Date(x.getFullYear(), x.getMonth() + 1, 0).getDate()));
  setCells_('Renewals', r._row, { NextDate: x });
}
function saveExpense(token, e) {
  var s = auth_(token);
  return withLock_(function () {
    if (num_(e.amount) <= 0) throw new Error('Enter the amount');
    var rec = { Date: e.date ? new Date(e.date + 'T00:00:00') : new Date(), Company: e.company, Category: e.category || 'Other', Description: e.description || '',
      Amount: num_(e.amount), Currency: e.currency === 'USD' ? 'USD' : 'LKR', Method: e.method || 'Cash', User: s.u };
    if (e.id) {
      var row = rows_('Expenses').filter(function (x) { return String(x.ID) === String(e.id); })[0];
      if (!row) throw new Error('Expense not found');
      setCells_('Expenses', row._row, rec);
    } else { rec.ID = nextNo_('ExpenseCounter', 'E', 5); append_('Expenses', rec); }
    return LITE ? (e.id || rec.ID) : allData_();
  });
}
function deleteExpense(token, id) {
  auth_(token);
  return withLock_(function () {
    var row = rows_('Expenses').filter(function (x) { return String(x.ID) === String(id); })[0];
    if (row) sh_('Expenses').deleteRow(row._row);
    return data_();
  });
}

/* ───────── helpers ───────── */
function ss_() { return SpreadsheetApp.getActiveSpreadsheet(); }
function sh_(name) {
  var s = ss_().getSheetByName(name);
  if (!s && name === 'DocCosts') {
    s = ss_().insertSheet(name);
    s.getRange(1, 1, 1, SHEETS[name].length).setValues([SHEETS[name]]).setFontWeight('bold').setBackground('#0B1A33').setFontColor('#FFFFFF');
    s.setFrozenRows(1); s.getRange(2, 1, s.getMaxRows() - 1, 1).setNumberFormat('@');
  }
  if (!s) throw new Error('Sheet "' + name + '" is missing. Run setup() first.');
  return s;
}
function rows_(name) {
  var v = sh_(name).getDataRange().getValues();
  var head = v.shift() || [];
  return v.map(function (r, i) { var o = { _row: i + 2 }; head.forEach(function (k, j) { o[k] = r[j]; }); return o; })
    .filter(function (o) { return head.some(function (k) { return o[k] !== '' && o[k] !== null; }); });
}
function append_(name, obj) { sh_(name).appendRow(SHEETS[name].map(function (k) { return obj[k] === undefined ? '' : obj[k]; })); }
function appendMany_(name, objs) {
  if (!objs.length) return;
  var s = sh_(name), head = SHEETS[name];
  s.getRange(s.getLastRow() + 1, 1, objs.length, head.length)
    .setValues(objs.map(function (o) { return head.map(function (k) { return o[k] === undefined ? '' : o[k]; }); }));
}
function setCells_(name, row, obj) {
  var s = sh_(name), head = SHEETS[name];
  Object.keys(obj).forEach(function (k) { var c = head.indexOf(k); if (c >= 0) s.getRange(row, c + 1).setValue(obj[k]); });
}
function settings_() { var o = {}; rows_('Settings').forEach(function (r) { o[r.Key] = r.Value; }); return o; }
function nextNo_(key, prefix, pad) {
  var r = rows_('Settings').filter(function (x) { return x.Key === key; })[0];
  var n = (r ? num_(r.Value) : 0) + 1;
  if (r) setCells_('Settings', r._row, { Value: String(n) }); else append_('Settings', { Key: key, Value: String(n) });
  return prefix + ('0000000000' + n).slice(-pad);
}
function auth_(token) {
  var c = CacheService.getScriptCache(), v = token && c.get('s_' + token);
  if (!v && token) {
    var r = rows_('Sessions').filter(function (x) { return x.Token === token; })[0];
    if (r && asDate_(r.Expires) > new Date()) {
      var u = rows_('Users').filter(function (x) { return x.Username === r.Username && isOn_(x.Active); })[0];
      if (u) v = JSON.stringify({ u: u.Username, n: u.Name, r: u.Role });
    }
  }
  if (!v) throw new Error('SESSION_EXPIRED');
  c.put('s_' + token, v, 21600);
  return JSON.parse(v);
}
var LOCKED_ = false;
function withLock_(fn) {
  if (LOCKED_) return fn();
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(25000)) throw new Error('System is busy, please try again');
  LOCKED_ = true;
  try { return fn(); } finally { LOCKED_ = false; lock.releaseLock(); }
}
function hash_(pw, salt) {
  var b = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, salt + pw, Utilities.Charset.UTF_8);
  return b.map(function (x) { return ('0' + ((x + 256) % 256).toString(16)).slice(-2); }).join('');
}
function num_(v) { var n = Number(String(v === null || v === undefined ? '' : v).replace(/,/g, '')); return isFinite(n) ? n : 0; }
function round_(n) { return Math.round(n * 100) / 100; }
function isOn_(v) { return v === true || String(v).toUpperCase() === 'TRUE'; }
function asDate_(v) { return v instanceof Date ? v : new Date(v); }
function ymd_(v) { var d = asDate_(v); return isNaN(d) ? '' : Utilities.formatDate(d, Session.getScriptTimeZone(), 'yyyy-MM-dd'); }
